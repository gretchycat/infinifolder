mkdir -p ./filesystem-test-images
cd ./filesystem-test-images || exit 1

make_image() {
  name="$1"
  shift

  img="${name}.img"
  truncate -s 20M "$img"

  echo "Formatting $img..."

  if "$@" "$img"; then
    echo "OK: $img"
  else
    echo "FAILED: $img"
    rm -f "$img"
  fi
}

run_format() {
  name="$1"
  tool="$2"
  shift 2

  if command -v "$tool" >/dev/null 2>&1; then
    make_image "$name" "$tool" "$@"
  else
    echo "SKIPPED: $name ($tool not installed)"
  fi
}

# FAT
run_format fat12 mkfs.fat -F 12
run_format fat16 mkfs.fat -F 16
run_format fat32 mkfs.fat -F 32

# exFAT
run_format exfat mkfs.exfat

# Linux ext
run_format ext2 mkfs.ext2 -F
run_format ext3 mkfs.ext3 -F
run_format ext4 mkfs.ext4 -F

# NTFS
run_format ntfs mkfs.ntfs -F -Q

# Other Linux filesystems
run_format btrfs mkfs.btrfs -f
run_format xfs mkfs.xfs -f
run_format f2fs mkfs.f2fs -f

# Classic Macintosh HFS
run_format hfs hformat

# HFS+
run_format hfsplus mkfs.hfsplus

# UDF
run_format udf mkudffs

echo
echo "Generated images:"
ls -lh *.img 2>/dev/null

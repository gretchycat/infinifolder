Infinifolder fixture: browsing, extraction, copying and deletion.
